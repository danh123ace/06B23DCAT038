# LibMan - JSP Web Application

Ứng dụng web Java theo mô hình Maven WAR, dùng JSP cho các trang, model/entity cho dữ liệu, DAO gọi stored procedure và service xử lý nghiệp vụ đăng ký thẻ. Cấu trúc được cấu hình để import vào Eclipse Enterprise Java/Web:

- `src/main/java`: model, DAO, service Java.
- `src/main/resources`: schema, seed và stored procedure MariaDB.
- `src/main/webapp`: JSP, CSS, `WEB-INF/web.xml`.
- `.project`, `.classpath`, `.settings`: cấu hình Eclipse Web Application.

## Các luồng JSP

- Đăng nhập, phân vai trò: `dangnhap.jsp` → `DoLogin8.jsp`.
- Bạn đọc: `ReaderHomeFrm8.jsp` → `RegisterReaderCardFrm8.jsp` → `DoRegisterReaderCard8.jsp`.
- Quản lý: `ManagerHomeFrm8.jsp` → `SelectStatisticHomeFrm8.jsp` → `SupplierStatisticFrm8.jsp` → `ImportInvoiceListFrm8.jsp` → `ImportInvoiceDetailFrm8.jsp`.
- `Logout8.jsp` kết thúc session.

JSP xác thực role qua session server; các trang thống kê xác thực manager với cơ sở dữ liệu. `RegisterReaderCardFrm8.jsp` dùng `ReaderDAO8` và `ReaderCardDAO8` để tải hồ sơ/thẻ; `DoRegisterReaderCard8.jsp` kiểm tra dữ liệu, mở transaction, cập nhật hồ sơ và gọi DAO cấp thẻ. Các DAO dùng stored procedure qua `CallableStatement`.

## Database MariaDB trong XAMPP

1. Chạy `src/main/resources/xampp_supplier_statistics.sql` nếu cần tạo schema và 15 bộ dữ liệu ban đầu.
2. Chạy `src/main/resources/xampp_supplier_statistics_extra20.sql` để thêm 5 nhà cung cấp, 20 hóa đơn và 40 dòng chi tiết nhập trong tháng 11/2026. Báo cáo từ 01/11/2026 đến 12/11/2026 có 20 nhà cung cấp, tổng 1.095 cuốn; mỗi hóa đơn có 2 tài liệu chi tiết.
3. Chạy `src/main/resources/xampp_jsp_procedures.sql` trong database `libman` để thêm subtype tables, bảng `reader_card` và stored procedures.
4. Đảm bảo tài khoản bạn đọc/quản lý có `password_hash` BCrypt. Đặt JDBC tùy chọn bằng biến môi trường `LIBMAN_JDBC_URL`, `LIBMAN_DB_USER`, `LIBMAN_DB_PASSWORD`; mặc định là `jdbc:mariadb://127.0.0.1:3306/libman`, user `root`, mật khẩu rỗng.

## Đóng gói và chạy

Yêu cầu JDK 17, Maven và Apache Tomcat 8.5 trở lên. Descriptor Servlet 3.1 tương thích với Tomcat 8.5 trong XAMPP. Chạy `mvn clean package`, sau đó deploy `target/libman.war` vào Tomcat và mở `http://localhost:8080/libman/`. Apache HTTPD của XAMPP chỉ phục vụ PHP/HTML tĩnh; JSP cần được chạy trên Tomcat.

Tài khoản quản lý demo: username `manager`, mật khẩu `123`. Tài khoản bạn đọc mẫu: `reader01` đến `reader05`, mật khẩu `123`. Các tài khoản này được lưu BCrypt trong database XAMPP hiện tại.
